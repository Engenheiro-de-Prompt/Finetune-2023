import os
import json

src_dir = 'Arquivos/'

def open_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as infile:
        return infile.read()

if __name__ == '__main__':
    files = os.listdir(src_dir)
    chat_data = []
    for file in files:
        text = open_file(src_dir + file)
        chunks = text.split('Dados:')
        if len(chunks) == 2:
            # Construindo o diálogo com mensagens de 'system', 'user' e 'assistant'
            messages = []
            messages.append({"role": "system", "content": chunks[0].strip()})
            messages.append({"role": "user", "content": chunks[1].strip()})
            # Adicionando uma mensagem do assistente (pode ser um placeholder ou uma resposta relevante)
            messages.append({"role": "assistant", "content": "Resposta do assistente"})

            chat_data.append({"messages": messages})

    with open('resultado.jsonl', 'w', encoding='utf-8') as outfile:
        for chat in chat_data:
            json.dump(chat, outfile)
            outfile.write('\n')
